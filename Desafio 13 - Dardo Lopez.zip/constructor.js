class AlimentoPerros {
  constructor(aId, aNombre, aStock, aPrecio, aImg, aDescripcion, aVendidos) {
    this.id = aId;
    this.nombre = aNombre;
    this.stock = aStock;
    this.precio = aPrecio;
    this.img = aImg;
    this.descripcion = aDescripcion;
    this.vendidos = aVendidos;
  }
}
